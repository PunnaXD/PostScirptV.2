-- FackBook : Max Sulataul

-- Github : https://github.com/PunnaXD

-- Discord : https://discord.gg/bkgP35skEv


config = {
    comando = {'k'},   --- komut

    acls = {
        {'Console'},
        {'Admin'},
    }
}


-- FackBook : Max Sulataul
-- Github : https://github.com/PunnaXD
-- Discord : https://discord.gg/bkgP35skEv