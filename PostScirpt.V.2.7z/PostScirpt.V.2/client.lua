-- FackBook : Max Sulataul

-- Github : https://github.com/PunnaXD

-- Discord : https://discord.gg/bkgP35skEv


local x, y = guiGetScreenSize()
local link = "http://mta/"..getResourceName(getThisResource()).."/web-side/index.html"
local browser = createBrowser(x, y, true, true, false)
local talking = false


setDevelopmentMode(true, true)

function dxNUII()
    dxDrawImage(0, 0, x, y, browser)  
end
addEventHandler('onClientRender', getRootElement(), dxNUII) 

function SendNUIMessage(browser, table)
    if isElement(browser) and type(table) == "table" then
       return executeBrowserJavascript(browser, 'window.postMessage('..toJSON(table)..'[0])')
    end
 end

addEvent("notifye", true)
addEventHandler("notifye", getRootElement(), function(css, mensagem)
    SendNUIMessage(browser, { css = css, mensagem = mensagem })
end)

addEventHandler("onClientBrowserCreated", browser, function()
    loadBrowserURL(source, link)
end)



-- FackBook : Max Sulataul



-- Github : https://github.com/PunnaXD 

-- Discord : https://discord.gg/bkgP35skEv