-- Sitemiz : https://sparrow-mta.blogspot.com/

-- Facebook : https://facebook.com/sparrowgta/
-- İnstagram : https://instagram.com/sparrowmta/
-- YouTube : https://youtube.com/c/SparroWMTA/

-- Discord : https://discord.gg/DzgEcvy

-------------------------- AUTOR: MCNXX* -------------

addCommandHandler(config.comando[1], function(source, cmd, ...)
    for i,v in ipairs(config.acls) do 
        local msg = table.concat({...}, " ")
        if msg:gsub(" ", "") ~= "" then
            local account = getPlayerAccount(source)
            if not isGuestAccount(account) then
                local accountName = getAccountName(account)
                 if isObjectInACLGroup ("user."..accountName, aclGetGroup (v[1])) then
                    triggerClientEvent(source, 'notifye', source, 'aviso', msg)
                 end
             end
        end
    end
end)


-- Sitemiz : https://sparrow-mta.blogspot.com/

-- Facebook : https://facebook.com/sparrowgta/
-- İnstagram : https://instagram.com/sparrowmta/
-- YouTube : https://youtube.com/c/SparroWMTA/

-- Discord : https://discord.gg/DzgEcvy